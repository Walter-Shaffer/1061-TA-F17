// Ronald (Trip) Bastian
// September 5, 2017
// CPSC 1061 Section 2

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}